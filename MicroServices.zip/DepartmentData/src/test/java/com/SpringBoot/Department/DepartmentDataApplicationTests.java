package com.SpringBoot.Department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
